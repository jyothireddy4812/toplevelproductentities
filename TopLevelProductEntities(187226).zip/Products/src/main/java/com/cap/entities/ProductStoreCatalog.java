package com.cap.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "ProductStoreCatalog")
public class ProductStoreCatalog implements Serializable {
	@Id
	@GeneratedValue
	private Integer prodCatalogId;
	private int productStoreId;
	private Date fromDate;
	private Date thruDate;
	private int sequeneceNum;
	public ProductStoreCatalog() {
		
	}
	public ProductStoreCatalog(int prodCatalogId, int productStoreId, Date fromDate, Date thruDate, int sequeneceNum) {
		super();
		this.prodCatalogId = prodCatalogId;
		this.productStoreId = productStoreId;
		this.fromDate = fromDate;
		this.thruDate = thruDate;
		this.sequeneceNum = sequeneceNum;
	}
	public Integer getProdCatalogId() {
		return prodCatalogId;
	}
	public void setProdCatalogId(Integer prodCatalogId) {
		this.prodCatalogId = prodCatalogId;
	}
	public int getProductStoreId() {
		return productStoreId;
	}
	public void setProductStoreId(int productStoreId) {
		this.productStoreId = productStoreId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getThruDate() {
		return thruDate;
	}
	public void setThruDate(Date thruDate) {
		this.thruDate = thruDate;
	}
	public int getSequeneceNum() {
		return sequeneceNum;
	}
	public void setSequeneceNum(int sequeneceNum) {
		this.sequeneceNum = sequeneceNum;
	}
	@Override
	public String toString() {
		return "ProductStoreCatalog [prodCatalogId=" + prodCatalogId + ", productStoreId=" + productStoreId
				+ ", fromDate=" + fromDate + ", thruDate=" + thruDate + ", sequeneceNum=" + sequeneceNum + "]";
	}
}
