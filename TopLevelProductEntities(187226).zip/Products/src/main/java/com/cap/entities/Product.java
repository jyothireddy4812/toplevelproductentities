package com.cap.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@SuppressWarnings("serial")
@Entity
@Table(name = "Product")
public class Product implements Serializable {
	@Id
	@GeneratedValue
	private Integer productId;
	private int productTypeId;
	private int primaryProductCategooryId;
	private int manfacturerPartyId;
	private int facilityId;
	private String productName;
	private int reuirementMenthodEnumID;
	private int configId;
	@ManyToOne
	@JsonBackReference(value="productcategory_product")
	@JoinColumn(name="pcm_productid",nullable= false)
	private ProductCategoryMember procatmem;
	

	public Product() {

	}

	public Product(Integer productId, int productTypeId, int primaryProductCategooryId, int manfacturerPartyId,
			int facilityId, String productName, int reuirementMenthodEnumID, int configId,
			ProductCategoryMember productCategoryMember) {
		super();
		this.productId=productId;
		this.productTypeId = productTypeId;
		this.primaryProductCategooryId = primaryProductCategooryId;
		this.manfacturerPartyId = manfacturerPartyId;
		this.facilityId = facilityId;
		this.productName = productName;
		this.reuirementMenthodEnumID = reuirementMenthodEnumID;
		this.configId = configId;
	
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public int getProductTypeId() {
		return productTypeId;
	}

	public void setProductTypeId(int productTypeId) {
		this.productTypeId = productTypeId;
	}

	public int getPrimaryProductCategooryId() {
		return primaryProductCategooryId;
	}

	public void setPrimaryProductCategooryId(int primaryProductCategooryId) {
		this.primaryProductCategooryId = primaryProductCategooryId;
	}

	public int getManfacturerPartyId() {
		return manfacturerPartyId;
	}

	public void setManfacturerPartyId(int manfacturerPartyId) {
		this.manfacturerPartyId = manfacturerPartyId;
	}

	public int getFacilityId() {
		return facilityId;
	}

	public void setFacilityId(int facilityId) {
		this.facilityId = facilityId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getReuirementMenthodEnumID() {
		return reuirementMenthodEnumID;
	}

	public void setReuirementMenthodEnumID(int reuirementMenthodEnumID) {
		this.reuirementMenthodEnumID = reuirementMenthodEnumID;
	}

	public int getConfigId() {
		return configId;
	}

	public void setConfigId(int configId) {
		this.configId = configId;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productTypeId=" + productTypeId + ", primaryProductCategooryId="
				+ primaryProductCategooryId + ", manfacturerPartyId=" + manfacturerPartyId + ", facilityId="
				+ facilityId + ", productName=" + productName + ", reuirementMenthodEnumID=" + reuirementMenthodEnumID
				+ ", configId=" + configId + "]";
	}
	

}
