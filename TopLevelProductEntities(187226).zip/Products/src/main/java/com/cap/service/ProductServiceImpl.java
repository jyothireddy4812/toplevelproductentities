package com.cap.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.ProductDao;
import com.cap.entities.Product;
@Service
@Transactional
public class ProductServiceImpl implements ProductService{
	@Autowired
    ProductDao dao;
	@Override
	public Product create(Product product) {
		//product.setProductCategoryMember(productCategoryMember);
		//productCategoryMember.setProduct(product);
		return dao.save(product);
	}

	/*
	 * @Override public Product update(Product product, ProductCategoryMember
	 * productCategoryMember) {
	 * product.setProductCategoryMember(productCategoryMember);
	 * productCategoryMember.setProduct(product); return dao.save(product); }
	 */

	@Override
	public void delete(Integer productId) {
		dao.deleteById(productId);
		
	}

	@Override
	public Optional<Product> findProduct(Integer productId) {
		return dao.findById(productId);
	}

	@Override
	public Product update(Product product) {
		//product.setProductCategoryMember(productCategoryMember);
		//productCategoryMember.setProduct(product);
		return dao.save(product);
	}

	

	

}
