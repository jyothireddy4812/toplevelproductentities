package com.cap.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.ProductCategoryMemberDao;
import com.cap.entities.ProductCategoryMember;
@Service
@Transactional
public class ProductCategoryMemberServiceImpl implements ProductCategoryMemberService{
	@Autowired
    ProductCategoryMemberDao dao;
	@Override
	public Optional<ProductCategoryMember> findProductCategoryMember(Integer productId) {
		return dao.findById(productId);
	}
	@Override
	public void delete(Integer productId) {
		dao.deleteById(productId);
		
	}
	@Override
	public ProductCategoryMember update(ProductCategoryMember productCategoryMember) {
		return dao.save(productCategoryMember);
	}
	@Override
	public ProductCategoryMember create(ProductCategoryMember productCategoryMember) {
		return dao.save(productCategoryMember);
	}
	@Override
	public Optional<ProductCategoryMember> findProductStoreCatalog(Integer productCatalogId) {
		return dao.findById(productCatalogId);
	}
}
