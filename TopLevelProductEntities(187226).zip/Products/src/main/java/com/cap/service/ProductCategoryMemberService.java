package com.cap.service;

import java.util.Optional;

import com.cap.entities.ProductCategoryMember;

public interface ProductCategoryMemberService {
	Optional<ProductCategoryMember> findProductCategoryMember(Integer productId);

	void delete(Integer productId);

	ProductCategoryMember update(ProductCategoryMember productCategoryMember);

	ProductCategoryMember create(ProductCategoryMember productCategoryMember);

	Optional<ProductCategoryMember> findProductStoreCatalog(Integer productCatalogId);
}
