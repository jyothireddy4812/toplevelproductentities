package com.cap.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.ProductStoreCatalogDao;
import com.cap.entities.ProductStoreCatalog;
@Service
@Transactional
public class ProductStoreCatalogServiceImpl implements ProductStoreCatalogService{
	@Autowired
    ProductStoreCatalogDao dao;
	@Override
	public ProductStoreCatalog create(ProductStoreCatalog productStoreCatalog) {
		return dao.save(productStoreCatalog);
	}

	@Override
	public ProductStoreCatalog update(ProductStoreCatalog productStoreCatalog) {
		return dao.save(productStoreCatalog);
	}

	@Override
	public void delete(Integer productCatalogId) {
		dao.deleteById(productCatalogId);
	}

	@Override
	public Optional<ProductStoreCatalog> findProductStoreCatalog(Integer productCatalogId) {
		return dao.findById(productCatalogId);
	}

}
