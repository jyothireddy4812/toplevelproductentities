package com.cap.service;

import java.util.Optional;

import com.cap.entities.ProductStoreCatalog;

public interface ProductStoreCatalogService {

	ProductStoreCatalog create(ProductStoreCatalog productStoreCatalog);

	ProductStoreCatalog update(ProductStoreCatalog productStoreCatalog);

	void delete(Integer productCatalogId);

	Optional<ProductStoreCatalog> findProductStoreCatalog(Integer productCatalogId);


}
