package com.cap.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cap.entities.Product;
import com.cap.entities.ProductCategoryMember;
import com.cap.service.ProductCategoryMemberServiceImpl;
import com.cap.service.ProductService;
import com.cap.service.ProductServiceImpl;
@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductsApplicationTests {
	ProductService service=new ProductServiceImpl();
	ProductCategoryMemberServiceImpl pservice=new ProductCategoryMemberServiceImpl();
	@Test
	public void  createProduct() {
		Product product=new Product();
		product.setConfigId(12);
		product.setProductId(11);//dummy
		product.setManfacturerPartyId(121);
		product.setProductName("atom");
		product.setPrimaryProductCategooryId(143);
		product.setFacilityId(154);
		Product result=service.create(product);
		assertNotEquals(null,result);
	}
	@Test
	public void  createProductCategoryMember() {
		Product product=new Product();
		product.setConfigId(12);
		product.setProductId(11);//dummy
		product.setManfacturerPartyId(121);
		product.setProductName("atom");
		product.setPrimaryProductCategooryId(143);
		product.setFacilityId(154);
		Product product2=new Product();
		product.setConfigId(12);
		product.setProductId(11);//dummy
		product.setManfacturerPartyId(121);
		product.setProductName("atom");
		product.setPrimaryProductCategooryId(143);
		product.setFacilityId(154);
		List<Product> products=new ArrayList<Product>();
		products.add(product);
		products.add(product2);
		ProductCategoryMember product1=new ProductCategoryMember();
		product1.setProductCategoryId(12);
		product1.setProductId(11);//dummy
		product1.setQuantity(120);
		product1.setProducts(products);
		ProductCategoryMember result=pservice.create(product1);
		assertEquals(null,result);
	}
	@Test
	public void  deleteProductCategoryMember() {
		pservice.delete(1);
		Optional<ProductCategoryMember> result=pservice.findProductCategoryMember(1);
		assertEquals(null, result);
	}
	@Test
	public void  findProductCategoryMember() {
		Optional<ProductCategoryMember> result=pservice.findProductCategoryMember(1);
		assertNotEquals(null, result);
	}
}
